export default function Home() {
  return (
    <div className="p-6">
      <h1 className="text-3xl font-bold mb-4">Selamat Datang di Go Tour Lombok</h1>
      <p>Jelajahi keindahan Lombok bersama kami!</p>
    </div>
  );
}