import { useState } from "react";

export default function BookingForm() {
  const [jumlahOrang, setJumlahOrang] = useState(1);
  const [hargaPerOrang, setHargaPerOrang] = useState(50000);
  const [totalHarga, setTotalHarga] = useState(50000);

  const handleJumlahChange = (e) => {
    const jumlah = parseInt(e.target.value);
    setJumlahOrang(jumlah);
    setTotalHarga(jumlah * hargaPerOrang);
  };

  return (
    <form className="space-y-4">
      <input type="text" placeholder="Nama" className="border p-2 w-full" required />
      <input type="date" className="border p-2 w-full" required />
      <input 
        type="number" 
        value={jumlahOrang}
        onChange={handleJumlahChange}
        min="1"
        className="border p-2 w-full" 
        required
      />
      <div className="font-semibold">
        Harga Total: Rp{totalHarga.toLocaleString("id-ID")}
      </div>
      <button type="submit" className="bg-blue-500 text-white px-4 py-2 rounded">
        Pesan Sekarang
      </button>
    </form>
  );
}